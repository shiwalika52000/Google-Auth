To run the project follow the below commands :

1. npm i
2. node inde.js

