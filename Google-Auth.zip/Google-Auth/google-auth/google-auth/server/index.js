const express = require('express');
const app = express();
const passport = require('passport');
const session = require('express-session'); 
require('./passport'); 


app.use(session({
    secret: 'your secret id',
    resave: false,
    saveUninitialized: false
  }));
  
  app.use(passport.initialize());
  app.use(passport.session());
	


app.get('/', (req, res) => { 
	res.send("<button><a href='/auth'>Login With Google</a></button>") 
}); 

// app.get('/logout', (req, res) => { 
// 	res.send("<button><a href='/auth'>Logout</a></button>") 
// }); 

// Auth 
app.get('/auth' , passport.authenticate('google', { scope: 
	[ 'email', 'profile' ] 
})); 

// Auth Callback 
app.get( '/auth/callback', 
	passport.authenticate( 'google', { 
		successRedirect: '/auth/callback/success', 
		failureRedirect: '/auth/callback/failure'
})); 

// Success 
// app.get('/auth/callback/success' , (req , res) => { 
// 	if(!req.user) 
// 		res.redirect('/auth/callback/failure'); 
//     res.send("welcome Dude! " + "<button><a href='/'>Logout</a></button>")
// }); 


app.get('/auth/callback/success', (req, res) => {
  if (req.user) {

      // If user is authenticated, display the welcome page
      res.send(`
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f0f0f0;
                    text-align: center;
                }
                .container {
                    max-width: 600px;
                    margin: 50px auto;
                    padding: 20px;
                    background-color: #fff;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                }
                button {
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: #fff;
                    border: none;
                    cursor: pointer;
                    border-radius: 4px;
                    text-decoration: none;
                    margin-top: 10px;
                }
                button:hover {
                    background-color: #0056b3;
                }
                form {
                    margin-top: 20px;
                }
                input[type="text"] {
                    padding: 8px;
                    width: 300px;
                    margin-right: 10px;
                }
            </style>
        </head>
        <body>
            <div class="container" style="color: skyblue; background-color: black;">
                <h2 style="color: yellow";>Welcome ${req.user.displayName}!</h2>
                <p>Education: Empowering Individuals and Transforming Societies
Education is a cornerstone of human development, playing a pivotal role in shaping individuals, societies, and economies worldwide. It encompasses formal schooling, informal learning, vocational training, and lifelong education, each contributing uniquely to personal growth, social cohesion, and economic progress. In this essay, we explore the multifaceted dimensions of education, its societal impact, challenges, and the evolving landscape in a globalized world.

The Essence of Education
At its core, education empowers individuals with knowledge, skills, and values essential for personal and professional success. Formal education, typically imparted through schools, colleges, and universities, provides structured learning environments where foundational concepts are taught across various disciplines. It equips learners with literacy, numeracy, critical thinking, and problem-solving abilities, essential for navigating modern complexities. Beyond academics, education fosters social skills, emotional intelligence, and ethical values, nurturing well-rounded individuals capable of contributing meaningfully to society.

Societal Benefits of Education
Education transcends individual benefits, influencing societal outcomes profoundly. Educated populations tend to exhibit higher levels of civic engagement, contributing to democratic processes and community development. Moreover, education promotes social mobility by offering equal opportunities for advancement regardless of background or socio-economic status. It serves as a catalyst for reducing inequalities, bridging divides, and promoting inclusive growth.

Economic Impact
Economically, education is a driver of innovation, productivity, and competitiveness. Nations with well-educated workforces are better positioned to adapt to technological advancements and global market demands. Education fosters entrepreneurship, creating new industries and employment opportunities. Moreover, educated individuals typically earn higher incomes, leading to improved living standards and overall prosperity.

 </p>
                <button><a href='/'>Logout</a></button>
            </div>
        </body>
        </html>
    `);
} else {
    // If not authenticated, show the login button
    res.send("<button><a href='/auth'>Login With Google</a></button>");
}
});



// failure 
app.get('/auth/callback/failure' , (req , res) => { 
  res.send("Username or password wrong" + "<button><a href='/auth'>Login With Google</a></button>"); 
}) 


app.listen(4000 , () => { 
	console.log("Server Running on port 4000"); 
});
